#!/usr/bin/env bash
# BLASTn for sequence longer than 200bp
python ./21_rbh.py ctl -n 
python ./22_branch.py ctl
python ./23_calc_age.py ctl

# BLASTn for sequence less than 200bp
python ./21_rbh.py ctl_short -n -s
python ./22_branch.py ctl_short
python ./23_calc_age.py ctl_short

python ./24_merge.py