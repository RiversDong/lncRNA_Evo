import pandas as pd
import re

def compare_and_get_max_age(age1, age2):
    def get_num(val):
        if pd.isna(val):
            return -1
        match = re.search(r'B(\d+)', str(val))
        if match:
            return int(match.group(1))
        return 0 
    num1 = get_num(age1)
    num2 = get_num(age2)
    if num1 >= num2:
        return age1
    else:
        return age2

def process_gene_files(file1_path, file2_path, output_path):
    df1 = pd.read_csv(file1_path)
    df2 = pd.read_csv(file2_path)
    df_result = df1[['A_gene']].copy()

    b_columns = [f'B{i}' for i in range(1, 11)] 
    for col in b_columns:
        df_result[col] = ((df1[col].fillna(0).astype(bool)) | (df2[col].fillna(0).astype(bool))).astype(int)

    
    df_result['Age'] = [compare_and_get_max_age(a1, a2) for a1, a2 in zip(df1['Age'], df2['Age'])]

    
    sorted_b_cols = [f'B{i}' for i in range(10, 0, -1)] 
    final_columns = ['A_gene'] + sorted_b_cols + ['Age']
    df_result = df_result[final_columns]

    df_result.to_csv(output_path, index=False)

if __name__ == "__main__":
    file_age = 'age.csv'
    file_age_short = 'age_short.csv'
    output_file = 'lncRNA_merged_age.csv'
    try:
        process_gene_files(file_age, file_age_short, output_file)
    except Exception as e:
        print(f"{e}")