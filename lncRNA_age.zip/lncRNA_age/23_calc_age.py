import pandas as pd
import os
import sys

if len(sys.argv) < 2:
    print("Usage: python 4_calc_age.py <config_file>")
    sys.exit(1)

ctl = sys.argv[1]
if not os.path.exists(ctl):
    print(f"Error: Configuration file '{ctl}' not found.")
    sys.exit(1)

with open(ctl, 'r', encoding='utf-8') as f:
    ctl_text = f.read()

exec(ctl_text)

required_vars = ['BRANCH_DIS', 'AGE_DIST', 'ORDERED_KEYS']
for var in required_vars:
    if var not in globals():
        print(f"Error: Variable '{var}' is not defined in the configuration file.")
        sys.exit(1)


def get_oldest_origin(row, ordered_branches):
    for branch in ordered_branches:
        if branch in row and row[branch] == 1:
            return branch
    return "Unknown"

def main():
    input_file = BRANCH_DIS
    output_file = AGE_DIST
    if not os.path.exists(input_file):
        print(f"Error: Input file '{input_file}' not found.")
        return
    print(f"Reading {input_file}...")
    df = pd.read_csv(input_file)
    if 'A_gene' not in df.columns:
        print("Error: Column 'A_gene' is missing in the input file.")
        return
    missing_cols = [b for b in ORDERED_KEYS if b not in df.columns]
    if missing_cols:
        print(f"Error: The following branch columns are missing in CSV: {missing_cols}")
        print("Please check if 'branch2species' keys match 'ORDERED_KEYS'.")
        return

    print("Calculating Gene Age (Oldest Hit Principle)...")
    print(f"Scanning Order: {ORDERED_KEYS[0]} (Oldest) -> ... -> {ORDERED_KEYS[-1]} (Youngest)")

    df['Age'] = df.apply(lambda row: get_oldest_origin(row, ORDERED_KEYS), axis=1)

    print("\n[Age Distribution Summary]")
    age_counts = df['Age'].value_counts()
    
    for br in ORDERED_KEYS:
        count = age_counts.get(br, 0)
        print(f"  {br}: {count} genes")

    unknown_count = age_counts.get("Unknown", 0)
    if unknown_count > 0:
        print(f"  Unknown: {unknown_count} genes (Genes with no match in any branch)")

    
    print(f"\nSaving results to {output_file}...")
    df.to_csv(output_file, index=False)
    print("Done!")
    
    
    print("\nPreview:")
    print(df[['A_gene', 'Age'] + ORDERED_KEYS[:3]].head()) 

if __name__ == "__main__":
    main()