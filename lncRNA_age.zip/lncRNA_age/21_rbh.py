import os
import glob
import subprocess
import pandas as pd
import numpy as np
import shutil
import sys
import argparse 

'''
-n Blastn,blastn -task blastn ...
-n -s,Short Blastn,blastn -task blastn-short ...
-p,Blastp,blastp ...
-d,DIAMOND,diamond blastp ...
'''


parser = argparse.ArgumentParser(description="Mutual Rank Analysis Script")
parser.add_argument('config_file', help="Path to the configuration file (e.g., config.txt)")


group = parser.add_mutually_exclusive_group()
group.add_argument('-n', action='store_true', help="Nucleotide alignment (blastn) - Default")
group.add_argument('-p', action='store_true', help="Protein alignment (blastp)")
group.add_argument('-d', '--diamond', action='store_true', help="Fast Protein alignment (DIAMOND)") 


parser.add_argument('-s', '--short', action='store_true', help="Use '-task blastn-short' for nucleotide alignment (only works with -n)")

args = parser.parse_args()


ctl = args.config_file
if not os.path.exists(ctl):
    print(f"Error: Config file '{ctl}' not found.")
    sys.exit(1)

with open(ctl, 'r', encoding='utf-8') as f:
    ctl_text = f.read()


exec(ctl_text)


if args.diamond:
    ALIGN_TOOL = 'diamond'
    DB_TYPE_FLAG = 'prot'
    print("Mode: Fast Protein alignment (DIAMOND)")
elif args.p:
    ALIGN_TOOL = 'blastp'
    DB_TYPE_FLAG = 'prot'
    print("Mode: Protein alignment (Standard BLASTp)")
else:
    
    ALIGN_TOOL = 'blastn'
    DB_TYPE_FLAG = 'nucl'
    print("Mode: Nucleotide alignment (Standard BLASTn)")
    if args.short:
        print("      (Sub-mode: blastn-short enabled for short sequences)")

def check_tools_install():
    
    if ALIGN_TOOL == 'diamond':
        if shutil.which('diamond') is None:
             raise EnvironmentError("Error: Command 'diamond' not found. Please install DIAMOND (conda install -c bioconda diamond).")
    else:
        
        for cmd in ['makeblastdb', ALIGN_TOOL]:
            if shutil.which(cmd) is None:
                raise EnvironmentError(f"Error: Command '{cmd}' not found. Please install NCBI BLAST+.")

def get_gene_ids_from_fasta(fasta_path):
    
    ids = []
    with open(fasta_path, 'r') as f:
        for line in f:
            if line.startswith(">"):
                full_id = line.strip().split()[0].replace('>', '')
                ids.append(full_id)
    return pd.DataFrame(ids, columns=['A_gene'])

def make_db(fasta_file, db_name, db_type='nucl'):
    
    if os.path.getsize(fasta_file) == 0:
        print(f"Warning: {fasta_file} is empty. Skipping DB creation.")
        return

    if ALIGN_TOOL == 'diamond':
        
        
        cmd = [
            'diamond', 'makedb',
            '--in', fasta_file,
            '--db', db_name,
            '--quiet' 
        ]
    else:
        
        cmd = [
            'makeblastdb',
            '-in', fasta_file,
            '-dbtype', db_type,
            '-out', db_name,
        ]
    
    try:
        
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL if ALIGN_TOOL != 'diamond' else None)
    except subprocess.CalledProcessError as e:
        print(f"Error running database creation on {fasta_file}")
        raise e

def run_alignment(query, db, out_file):
    if ALIGN_TOOL == 'diamond':
        
        
        cmd = [
            'diamond', 'blastp',
            '-q', query,
            '-d', db,
            '-o', out_file,
            
            '-f', '6', 'qseqid', 'sseqid', 'pident', 'evalue', 'length', 
            '-e', str(EVALUE_THRESH),
            '-p', '4', 
            '--quiet',
            '--ultra-sensitive' 
        ]
    else:      
        cmd = [
            ALIGN_TOOL, '-query', query, '-db', db,
            '-out', out_file,               
            '-dust', 'yes',                 
            '-soft_masking', 'true',        
            '-best_hit_overhang', '0.1',    
            '-best_hit_score_edge', '0.1',  
            '-max_hsps', '1',               
            '-outfmt', '6 qseqid sseqid pident length qstart qend sstart send evalue bitscore qlen slen',
            '-evalue', str(EVALUE_THRESH), '-num_threads', '4']
        
        if ALIGN_TOOL == 'blastn':
            if args.short:
                cmd.extend(['-task', 'blastn-short'])
                cmd.extend(['-max_target_seqs', '200'])
            else:
                
                cmd.extend(['-task', 'dc-megablast']) 
                cmd.extend(['-word_size', '11'])
                cmd.extend(['-max_target_seqs', '50'])
    
    print(" ".join(cmd))  
    subprocess.run(cmd, check=True)

def process_blast_df(blast_file):
    col_names = ['qseqid', 'sseqid', 'pident', 'length', 'qstart', 'qend', 'sstart', 'send', 'evalue', 'bitscore', 'qlen', 'slen']
    if not os.path.exists(blast_file) or os.path.getsize(blast_file) == 0:
        return pd.DataFrame(columns=col_names)
    df = pd.read_csv(blast_file, sep='\t', names=col_names)
    df["qcov"] = df["length"]/df["qlen"]
    if ALIGN_TOOL == 'blastn' and not args.short: 
        
        df = df[df['pident'] >= IDENTITY_THRESH]
        mask_small = (df['qlen'] <= 1000) & (df['length'] >= 120)
        mask_large = (df['qlen'] > 1000)  & (df['length'] >= 200)
        
        
        df = df[mask_small | mask_large]
    else:     
        df = df[(df['pident'] >= SHORT_IDENTITY_THRESH) & (df['length'] >= 50)] 
    return df

def calculate_rank(df, group_col, rank_col_name):
    df_sorted = df.sort_values(by='evalue', ascending=True)
    df_sorted[rank_col_name] = df_sorted.groupby(group_col)['evalue'].rank(method='first', ascending=True)
    return df_sorted

def main():
    
    print(f"Current Working Directory: {os.getcwd()}")
    
    
    if not os.path.exists(TEMP_DIR):
        try:
            os.makedirs(TEMP_DIR)
            print(f"Created temporary directory: {TEMP_DIR}")
        except Exception as e:
            print(f"Error creating directory {TEMP_DIR}: {e}")
            return
    else:
        print(f"Using existing temporary directory: {TEMP_DIR}")

    check_tools_install()
    
    
    target_path = os.path.join(INPUT_DIR, TARGET_SPECIES_FILENAME)
    
    print(f"Looking for target file at: {os.path.abspath(target_path)}")
    
    if not os.path.exists(target_path):
        print(f"Error: Target file not found at {target_path}")
        print("Please check if your 'INPUT_DIR' in config is correct relative to where you run the command.")
        return

    print(f"Target Species A: {TARGET_SPECIES_FILENAME}")

    
    print("Extracting gene IDs from target species...")
    final_df = get_gene_ids_from_fasta(target_path)
    print(f"Total genes in A: {len(final_df)}")

    
    path_db_A = os.path.join(TEMP_DIR, "DB_A")
    make_db(target_path, path_db_A, db_type=DB_TYPE_FLAG)

    
    print("\nIdentifying comparison files from 'branch2species' configuration...")
    
    comparison_files = []
    if 'branch2species' not in globals():
        print("Error: 'branch2species' dictionary not found in config file.")
        return

    processed_filenames = set()
    
    for branch, files in branch2species.items():
        for filename in files:
            if filename == TARGET_SPECIES_FILENAME:
                continue
            if filename in processed_filenames:
                continue
            
            file_path = os.path.join(INPUT_DIR, filename)
            if not os.path.exists(file_path):
                print(f"Warning: File defined in branch2species not found: {filename} (Skipping)")
                continue
                
            comparison_files.append(file_path)
            processed_filenames.add(filename)

    print(f"Found {len(comparison_files)} species to compare against (excluding self).")

    if len(comparison_files) == 0:
        print("Error: No valid comparison files found.")
        return

    
    for b_path in comparison_files:
        b_filename = os.path.basename(b_path)
        species_name = b_filename
        col_match = f"Best_match_in_{species_name}"
        col_mr = f"MR_{species_name}"
        
        print(f"\nProcessing comparison: A vs {b_filename} using {ALIGN_TOOL}...")

        
        path_db_B = os.path.join(TEMP_DIR, "DB_B_temp")
        make_db(b_path, path_db_B, db_type=DB_TYPE_FLAG)

        
        out_A_to_B = os.path.join(TEMP_DIR, f"A_to_{species_name}.txt")
        run_alignment(query=target_path, db=path_db_B, out_file=out_A_to_B)
        
        df_ab = process_blast_df(out_A_to_B)
        df_ab = calculate_rank(df_ab, group_col='qseqid', rank_col_name='rank_ab')
        df_ab_slim = df_ab[['qseqid', 'sseqid', 'rank_ab']].rename(columns={'qseqid': 'A_id', 'sseqid': 'B_id'})

        
        out_B_to_A = os.path.join(TEMP_DIR, f"{species_name}_to_A.txt")
        run_alignment(query=b_path, db=path_db_A, out_file=out_B_to_A)
        
        df_ba = process_blast_df(out_B_to_A)
        df_ba = calculate_rank(df_ba, group_col='qseqid', rank_col_name='rank_ba')
        df_ba_slim = df_ba[['qseqid', 'sseqid', 'rank_ba']].rename(columns={'qseqid': 'B_id', 'sseqid': 'A_id'})

        
        merged = pd.merge(df_ab_slim, df_ba_slim, on=['A_id', 'B_id'], how='inner')
        merged['MR'] = np.sqrt(merged['rank_ab'] * merged['rank_ba'])

        
        best_matches = merged.sort_values('MR').drop_duplicates(subset=['A_id'], keep='first')
        
        result_subset = best_matches[['A_id', 'B_id', 'MR']].rename(columns={
            'A_id': 'A_gene',
            'B_id': col_match,
            'MR': col_mr
        })

        
        final_df = pd.merge(final_df, result_subset, on='A_gene', how='left')
    
    print(f"Saving results to {OUTPUT_CSV}...")
    final_df.to_csv(OUTPUT_CSV, index=False)
    print("Done!")

if __name__ == "__main__":
    try:
        import pandas
    except ImportError:
        print("Error: pandas is required. Please install it using 'pip install pandas'")
        exit(1)
    main()