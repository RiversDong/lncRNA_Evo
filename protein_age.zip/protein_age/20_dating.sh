#!/usr/bin/env bash

python ./21_rbh.py ctl -n 
python ./22_branch.py ctl
python ./23_calc_age.py ctl
