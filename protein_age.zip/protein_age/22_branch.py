import pandas as pd
import os
import numpy as np
import sys


ctl = sys.argv[1]
config_ns = {}
with open(ctl, 'r', encoding='utf-8') as f:
    ctl_text = f.read()
exec(ctl_text)
INPUT_RBH = OUTPUT_CSV

def main():
    
    if not os.path.exists(INPUT_RBH):
        print(f"Error: Input file '{INPUT_RBH}' not found.")
        return

    print(f"Reading {INPUT_RBH}...")
    df = pd.read_csv(INPUT_RBH)
    
    if 'A_gene' not in df.columns:
        print("Error: Column 'A_gene' not found in input CSV.")
        return
        
    
    result_df = df[['A_gene']].copy()
    
    print(f"\nProcessing branches (Target Species: {TARGET_SPECIES_FILENAME})...")
    
    
    for branch_name, file_list in branch2species.items():
        
        
        branch_contains_target = False
        relevant_columns = []
        
        for filename in file_list:
            
            if filename == TARGET_SPECIES_FILENAME:
                branch_contains_target = True
                
                break 
            
            
            expected_col = f"Best_match_in_{filename}"
            if expected_col in df.columns:
                relevant_columns.append(expected_col)
            else:
                
                print(f"  [Warning] Branch '{branch_name}': Column '{expected_col}' missing.")

        
        if branch_contains_target:
            
            print(f"  Branch '{branch_name}' contains Target Species. All set to 1.")
            result_df[branch_name] = 1
        else:
            
            if not relevant_columns:
                print(f"  [Warning] Branch '{branch_name}' has no matching columns. Filling with 0.")
                result_df[branch_name] = 0
            else:
                
                subset = df[relevant_columns]
                has_homolog = subset.notna().any(axis=1).astype(int)
                result_df[branch_name] = has_homolog
                print(f"  Branch '{branch_name}' processed. (Based on {len(relevant_columns)} comparison files)")

    
    print(f"\nSaving binary matrix to {BRANCH_DIS}...")
    result_df.to_csv(BRANCH_DIS, index=False)
    print("Done!")
    print("\nPreview:")
    print(result_df.head())

if __name__ == "__main__":
    main()